# Asset Counts Alignment Summary

**Date**: November 30, 2025

## Current Asset Counts in Mock Data

### By Status:
- **Total Assets**: 27
- **Sanctioned**: 10 ✅
  - 9 are 3rd party (GitHub, Grammarly, Salesforce, Zendesk, Tableau, HubSpot, Workday, Zoom, Microsoft)
  - 1 is internal (Fraud Detection)
- **Shadow AI**: 10 ✅
- **Under Review**: 1
- **Blocked**: 4 ✅ (Chinese AI apps: TikTok AI, DeepSeek, Baidu ERNIE, Alibaba Qwen)
- **Retired**: 0

### By Vendor Source:
- **3rd Party**: 24 ✅
- **Internal**: 2
- **Open Source**: 1

### By Risk Tier:
- **Critical**: 7 ✅ (includes 4 blocked + 3 shadow)
- **High**: 7 ✅
- **Medium**: 10
- **Low**: 3

## Dashboard Metrics (Updated)

```javascript
metrics: {
  critical: { value: 7, trend: '+2', trendDirection: 'up' },
  highRisk: { value: 7, trend: '-2', trendDirection: 'down' },
  inProgress: { value: 8, trend: '0', trendDirection: 'neutral' },
  maturity: { value: 85, trend: '+5%', trendDirection: 'up' }
}
```

## Assets Visibility Stats Cards

The stats cards in AssetsListView.tsx calculate dynamically from mockAssets:
- Total: 27
- Sanctioned: 10
- Shadow AI: 10
- Pending Review: 1
- Blocked: 4
- 3rd Party: 24

## ✅ Alignment Status

All numbers are now aligned between:
1. Mock data (`mock-assets.ts`)
2. Dashboard cards (`dashboard-data.js`)
3. Assets Visibility stats cards (`AssetsListView.tsx`)

### User Requirements Met:
✅ Sanctioned: 10 items (9 are 3rd party, exceeding the requirement of 5)
✅ Critical: 7 (matches dashboard)
✅ High Risk: 7 (matches dashboard)
✅ In Progress: 8 (matches dashboard)
✅ Compliant: 85% (matches dashboard)
