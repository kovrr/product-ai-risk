# KovrrAI User Credentials

**Application URL**: http://136.113.138.156:8000

---

## User Accounts

### Or
- **Username**: `or`
- **Email**: `or@kovrr.com`
- **Password**: `bTerAOX4xB`

### Shai
- **Username**: `shai`
- **Email**: `shai@kovrr.com`
- **Password**: `ZxItIMACEI`

### Yakir
- **Username**: `yakir`
- **Email**: `yakir@kovrr.com`
- **Password**: `qANLqq5fGZ`

### Naomi
- **Username**: `naomi`
- **Email**: `naomi@kovrr.com`
- **Password**: `AYAhgbGart`

### Huw
- **Username**: `huw`
- **Email**: `huw@kovrr.com`
- **Password**: `Sw4JTYmdZS`

### Alona
- **Username**: `alona`
- **Email**: `alona@kovrr.com`
- **Password**: `CSLVroXeJZ`

### Hannah
- **Username**: `hannah`
- **Email**: `hannah@kovrr.com`
- **Password**: `S2OeiSR0eX`

### Shalom
- **Username**: `shalom`
- **Email**: `shalom@kovrr.com`
- **Password**: `KCigje4XUE`

### Admin (Original)
- **Username**: `admin`
- **Email**: `admin@aikovrr.com`
- **Password**: `admin123` (unchanged)

---

## 🔒 Security Notes

- All passwords are 10 characters (mix of letters and numbers)
- Passwords were generated randomly
- Store this file securely
- Consider adding to `.gitignore` if committing

---

**Updated**: November 10, 2025
