export { AssetsListView } from './AssetsListView';
export { AssetDetailView } from './AssetDetailView';
