// New Assets Visibility with mock data
import { AssetsListView } from './AssetsVisibility/AssetsListView';

const AssetsVisibility = () => {
  return <AssetsListView />;
};

export default AssetsVisibility;
